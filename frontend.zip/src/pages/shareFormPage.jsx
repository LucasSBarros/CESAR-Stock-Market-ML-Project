import React from "react";
import {
  Flex,
  Box,
  FormControl,
  FormLabel,
  Input,
  HStack,
  Stack,
  Button,
  Heading,
  Text,
  useColorModeValue,
  Link,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import fetcher from "../services/api";

const ScheduleForm = () => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
    reset,
  } = useForm({
    defaultValues: {
      share: "VALE",
      startDate: "2021-01-01",
      endDate: "2024-09-02",
      days: 60,
    },
  });
  const [prediction, setPrediction] = React.useState(null);

  const onSubmit = async (data) => {
    setPrediction(null);
    try {
      console.log("Enviando dados:", data);

      const response = await fetcher.post("/api/shares", data, {
        headers: {
          'X-Custom-Header': 'value',
          'Content-Type': 'application/json'
        }
      });

      console.log("Resposta recebida:", response);
      setPrediction(response);
      reset(); 
    } catch (err) {
      console.error("Erro ao fazer requisição:", err);
      setError("apiError", {
        type: "manual",
        message: err?.response?.data?.error || "Erro ao fazer requisição",
      });
    }
  };

  return (
    <Flex
      minH={"100vh"}
      align={"center"}
      justify={"center"}
      bg={useColorModeValue("blackAlpha.900")}
    >
      <Stack spacing={8} mx={"auto"} maxW={"lg"} py={12} px={6}>
        <Stack align={"center"}>
          <Heading fontSize={"xxx-large"} textAlign={"center"} color={"green.400"}>
            Stock Market Predictions
          </Heading>
          <Text fontSize={"xl"} color={"white"}>
            Input the name of the share that you want to predict.
          </Text>
        </Stack>
        <Box rounded={"lg"} bg={useColorModeValue("white")} boxShadow={"xl"} p={8}>
          <Stack spacing={4} as="form" onSubmit={handleSubmit(onSubmit)}>
            <FormControl id="share" isRequired isInvalid={errors.share}>
              <FormLabel>Share</FormLabel>
              <Input
                type="text"
                {...register("share", { required: "Share is required" })}
              />
              {errors.share && <Text color="red.500">{errors.share.message}</Text>}
            </FormControl>

            <FormControl id="days" isRequired isInvalid={errors.days}>
              <FormLabel>Number of days</FormLabel>
              <Input
                type="number"
                {...register("days", { required: "Number of days is required" })}
              />
              {errors.days && <Text color="red.500">{errors.days.message}</Text>}
            </FormControl>

            <HStack>
              <Box>
                <FormControl id="startDate" isRequired isInvalid={errors.startDate}>
                  <FormLabel>Data inicial</FormLabel>
                  <Input
                    type="date"
                    {...register("startDate", { required: "Start date is required" })}
                  />
                  {errors.startDate && <Text color="red.500">{errors.startDate.message}</Text>}
                </FormControl>
              </Box>
              <Box>
                <FormControl id="endDate" isRequired isInvalid={errors.endDate}>
                  <FormLabel>Data final</FormLabel>
                  <Input
                    type="date"
                    {...register("endDate", { required: "End date is required" })}
                  />
                  {errors.endDate && <Text color="red.500">{errors.endDate.message}</Text>}
                </FormControl>
              </Box>
            </HStack>

            <Stack spacing={10} pt={2}>
              <Button
                type="submit"
                isLoading={isSubmitting}
                loadingText="Submitting"
                size="lg"
                bg={"green.400"}
                color={"white"}
                _hover={{
                  bg: "green.500",
                }}
              >
                Predict
              </Button>
            </Stack>
            {errors.apiError && <Text color="red.500">{errors.apiError.message}</Text>}
            {prediction && (
              <Box mt={4}>
                <Text fontSize="lg" color="green.400">
                  Prediction Results:
                </Text>
                <Text>Share: {prediction.ticker}</Text>
                <Text>Start Date: {prediction.start}</Text>
                <Text>End Date: {prediction.end}</Text>
                <Text>Prediction: {prediction.prediction.join(", ")}</Text>
              </Box>
            )}
            <Stack pt={6}>
              <Text align={"center"}>
                Deseja ver outras predições já realizadas?
                <br />
                <Link color={"green.400"}>Other predictions.</Link>
              </Text>
            </Stack>
          </Stack>
        </Box>
      </Stack>
    </Flex>
  );
};

export default ScheduleForm;