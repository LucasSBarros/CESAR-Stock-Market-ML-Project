class Config:
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:123456@localhost:5432/postgres"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
